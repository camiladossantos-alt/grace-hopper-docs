# Projeto Grace Hopper

AI-first voice interview preparation platform.

## Documentation Structure

- product-overview.md
- user-journey.md
- architecture.md
- ai-system.md
- design-system.md
- roadmap.md
- metrics.md
- glossary.md

## Core Stack

- Next.js
- FastAPI
- Supabase
- Gemini API
- Web Speech API
